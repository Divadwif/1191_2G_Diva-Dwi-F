<?php

namespace App\Http\Controllers;

use App\Models\Stok;
use Illuminate\Http\Request;

class StokController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stoks = Stok::latest()->paginate(5);
      
        return view('index',compact('stoks'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'barang' => 'required',
            'harga' => 'required',
            'stok' => 'required',
            'kategori' => 'required',
        ]);
      
        Stok::create($request->all());
       
        return redirect()->route('stoks.index')
                        ->with('success','Stok created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Stok $stok)
    {
        return view('show',compact('stok'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Stok $stok)
    {
        return view('edit',compact('stok'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Stok $stok)
    {
        $request->validate([
            'barang' => 'required',
            'review' => 'required',
        ]);
      
        $stok->update($request->all());
      
        return redirect()->route('stoks.index')
                        ->with('success','Stok updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Stok $stok)
    {
        $stok->delete();
       
        return redirect()->route('stoks.index')
                        ->with('success','Stok deleted successfully');
    }
}
